package hi.verkefni.traveldata;

public class ReservationCount extends Reservation {
    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
