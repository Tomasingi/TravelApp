package hi.verkefni.traveldata;
import java.util.ArrayList;
import java.util.List;

public class ReservationController {
    private final List<DayTour> dayTours = new ArrayList<>();
    private DayTour bookDayTour;


    public void addReservation(User user, DayTour dayTour, int people){

    }

    public void removeReservation(User user, DayTour dayTour){

    }



}
