package hi.verkefni.travelapp;

import hi.verkefni.traveldata.Reservation;
import javafx.scene.layout.HBox;

public class ReservationBodyView extends HBox {
    protected Reservation reservation;

    protected TravelView travelView;
}
